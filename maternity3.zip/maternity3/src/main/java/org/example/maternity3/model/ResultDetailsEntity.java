package org.example.maternity3.model;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "result_details", schema = "maternity", catalog = "")
public class ResultDetailsEntity {
    private int detailsId;
    private ResultEntity resultByResultId;
    private PatientResultEntity patientResultByPatientResultId;

    @Id
    @Column(name = "detailsID", nullable = false)
    public int getDetailsId() {
        return detailsId;
    }

    public void setDetailsId(int detailsId) {
        this.detailsId = detailsId;
    }











    @Override
    public int hashCode() {
        return Objects.hash(detailsId);
    }

    @ManyToOne
    @JoinColumn(name = "ResultID", referencedColumnName = "ResultID")
    public ResultEntity getResultByResultId() {
        return resultByResultId;
    }

    public void setResultByResultId(ResultEntity resultByResultId) {
        this.resultByResultId = resultByResultId;
    }

    @ManyToOne
    @JoinColumn(name = "Patient_resultID", referencedColumnName = "Patient_resultID")
    public PatientResultEntity getPatientResultByPatientResultId() {
        return patientResultByPatientResultId;
    }

    public void setPatientResultByPatientResultId(PatientResultEntity patientResultByPatientResultId) {
        this.patientResultByPatientResultId = patientResultByPatientResultId;
    }




}
