package org.example.maternity3.repository;

public class PatientDetails {
    Boolean isResultCopied;

}
