package org.example.maternity3.model;

import javax.persistence.*;
import java.util.Collection;
import java.util.Objects;

@Entity
@Table(name = "result", schema = "maternity", catalog = "")
public class ResultEntity {
    private int resultId;
    private String resultName;

    private CategoryEntity categoryByCategoryId;
    private Collection<ResultDetailsEntity> resultDetailsByResultId;

    @Id
    @Column(name = "ResultID", nullable = false)
    public int getResultId() {
        return resultId;
    }

    public void setResultId(int resultId) {
        this.resultId = resultId;
    }

    @Basic
    @Column(name = "Result_name", nullable = true, length = 100)
    public String getResultName() {
        return resultName;
    }

    public void setResultName(String resultName) {
        this.resultName = resultName;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ResultEntity that = (ResultEntity) o;
        return resultId == that.resultId && Objects.equals(resultName, that.resultName) ;
    }

    @Override
    public int hashCode() {
        return Objects.hash(resultId, resultName);
    }

    @ManyToOne
    @JoinColumn(name = "CategoryID", referencedColumnName = "CategoryID")
    public CategoryEntity getCategoryByCategoryId() {
        return categoryByCategoryId;
    }

    public void setCategoryByCategoryId(CategoryEntity categoryByCategoryId) {
        this.categoryByCategoryId = categoryByCategoryId;
    }

    @OneToMany(mappedBy = "resultByResultId")
    public Collection<ResultDetailsEntity> getResultDetailsByResultId() {
        return resultDetailsByResultId;
    }

    public void setResultDetailsByResultId(Collection<ResultDetailsEntity> resultDetailsByResultId) {
        this.resultDetailsByResultId = resultDetailsByResultId;
    }
}
