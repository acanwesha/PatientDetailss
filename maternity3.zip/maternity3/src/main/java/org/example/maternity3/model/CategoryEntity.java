package org.example.maternity3.model;

import javax.persistence.*;
import java.util.Collection;
import java.util.Objects;

@Entity
@Table(name = "category", schema = "maternity", catalog = "")
public class CategoryEntity {
    private int categoryId;
    private String categoryName;
    private Collection<ResultEntity> resultsByCategoryId;

    @Id
    @Column(name = "CategoryID", nullable = false)
    public int getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    @Basic
    @Column(name = "Category_name", nullable = true, length = 40)
    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CategoryEntity that = (CategoryEntity) o;
        return categoryId == that.categoryId && Objects.equals(categoryName, that.categoryName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(categoryId, categoryName);
    }

    @OneToMany(mappedBy = "categoryByCategoryId")
    public Collection<ResultEntity> getResultsByCategoryId() {
        return resultsByCategoryId;
    }

    public void setResultsByCategoryId(Collection<ResultEntity> resultsByCategoryId) {
        this.resultsByCategoryId = resultsByCategoryId;
    }
}
