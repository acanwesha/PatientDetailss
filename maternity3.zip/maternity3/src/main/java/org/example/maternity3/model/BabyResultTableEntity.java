package org.example.maternity3.model;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "baby_result_table", schema = "maternity", catalog = "")
public class BabyResultTableEntity {
    private int copyId;
    private String value;
    private String categoryName;
    private String resultName;
    private Timestamp dateTime;
    private ChildEntity childByChildId;

    @Id
    @Column(name = "copyID", nullable = false)
    public int getCopyId() {
        return copyId;
    }

    public void setCopyId(int copyId) {
        this.copyId = copyId;
    }


    @Basic
    @Column(name = "value", nullable = true, length = 50)
    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Basic
    @Column(name = "Category_name", nullable = true, length = 50)
    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    @Basic
    @Column(name = "Result_name", nullable = true, length = 50)
    public String getResultName() {
        return resultName;
    }

    public void setResultName(String resultName) {
        this.resultName = resultName;
    }

    @Basic
    @Column(name = "DateTime", nullable = true)
    public Timestamp getDateTime() {
        return dateTime;
    }

    public void setDateTime(Timestamp dateTime) {
        this.dateTime = dateTime;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BabyResultTableEntity that = (BabyResultTableEntity) o;
        return copyId == that.copyId && Objects.equals(value, that.value) && Objects.equals(categoryName, that.categoryName) && Objects.equals(resultName, that.resultName) && Objects.equals(dateTime, that.dateTime);
    }

    @Override
    public int hashCode() {
        return Objects.hash(copyId, value, categoryName, resultName, dateTime);
    }

    @ManyToOne
    @JoinColumn(name = "ChildID", referencedColumnName = "ChildID")
    public ChildEntity getChildByChildId() {
        return childByChildId;
    }

    public void setChildByChildId(ChildEntity childByChildId) {
        this.childByChildId = childByChildId;
    }
}
