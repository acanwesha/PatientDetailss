package org.example.maternity3.model;

import javax.persistence.*;
import java.util.Collection;
import java.util.Objects;

@Entity
@Table(name = "patient_result", schema = "maternity", catalog = "")
public class PatientResultEntity {
    private int patientResultId;

    private String value;

    private PatientEntity patientByPatientId;
    private ChildEntity childByChildId;
    private Collection<ResultDetailsEntity> resultDetailsByPatientResultId;
    private Collection<ResultDetailsEntity> resultDetailsByPatientResultId_0;
    private Collection<ResultDetailsEntity> resultDetailsByPatientResultId_1;

    @Id
    @Column(name = "Patient_resultID", nullable = false)
    public int getPatientResultId() {
        return patientResultId;
    }

    public void setPatientResultId(int patientResultId) {
        this.patientResultId = patientResultId;
    }


    @Basic
    @Column(name = "value", nullable = true, length = 50)
    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PatientResultEntity that = (PatientResultEntity) o;
        return patientResultId == that.patientResultId && Objects.equals(value, that.value) ;
    }

    @Override
    public int hashCode() {
        return Objects.hash(patientResultId,value);
    }

    @ManyToOne
    @JoinColumn(name = "PatientID", referencedColumnName = "PatientID")
    public PatientEntity getPatientByPatientId() {
        return patientByPatientId;
    }

    public void setPatientByPatientId(PatientEntity patientByPatientId) {
        this.patientByPatientId = patientByPatientId;
    }

    @ManyToOne
    @JoinColumn(name = "ChildID", referencedColumnName = "ChildID")
    public ChildEntity getChildByChildId() {
        return childByChildId;
    }

    public void setChildByChildId(ChildEntity childByChildId) {
        this.childByChildId = childByChildId;
    }

    @OneToMany(mappedBy = "patientResultByPatientResultId")
    public Collection<ResultDetailsEntity> getResultDetailsByPatientResultId() {
        return resultDetailsByPatientResultId;
    }

    public void setResultDetailsByPatientResultId(Collection<ResultDetailsEntity> resultDetailsByPatientResultId) {
        this.resultDetailsByPatientResultId = resultDetailsByPatientResultId;
    }

    @OneToMany(mappedBy = "patientResultByPatientResultId_0")
    public Collection<ResultDetailsEntity> getResultDetailsByPatientResultId_0() {
        return resultDetailsByPatientResultId_0;
    }

    public void setResultDetailsByPatientResultId_0(Collection<ResultDetailsEntity> resultDetailsByPatientResultId_0) {
        this.resultDetailsByPatientResultId_0 = resultDetailsByPatientResultId_0;
    }

    @OneToMany(mappedBy = "patientResultByPatientResultId_1")
    public Collection<ResultDetailsEntity> getResultDetailsByPatientResultId_1() {
        return resultDetailsByPatientResultId_1;
    }

    public void setResultDetailsByPatientResultId_1(Collection<ResultDetailsEntity> resultDetailsByPatientResultId_1) {
        this.resultDetailsByPatientResultId_1 = resultDetailsByPatientResultId_1;
    }
}
