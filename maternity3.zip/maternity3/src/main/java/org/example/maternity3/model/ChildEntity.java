package org.example.maternity3.model;

import javax.persistence.*;
import java.util.Collection;
import java.util.Objects;

@Entity
@Table(name = "child", schema = "maternity", catalog = "")
public class ChildEntity {
    private int childId;
    private String firstName;
    private String lastName;
    private String mrn;
    private String fin;

    private Collection<BabyResultTableEntity> babyResultTablesByChildId;
    private PatientEntity patientByPatientId;
    private Collection<PatientResultEntity> patientResultsByChildId;

    @Id
    @Column(name = "ChildID", nullable = false)
    public int getChildId() {
        return childId;
    }

    public void setChildId(int childId) {
        this.childId = childId;
    }

    @Basic
    @Column(name = "first_name", nullable = true, length = 40)
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @Basic
    @Column(name = "last_name", nullable = true, length = 40)
    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @Basic
    @Column(name = "MRN", nullable = false, length = 50)
    public String getMrn() {
        return mrn;
    }

    public void setMrn(String mrn) {
        this.mrn = mrn;
    }

    @Basic
    @Column(name = "FIN", nullable = false, length = 50)
    public String getFin() {
        return fin;
    }

    public void setFin(String fin) {
        this.fin = fin;
    }





    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ChildEntity that = (ChildEntity) o;
        return childId == that.childId && Objects.equals(firstName, that.firstName) && Objects.equals(lastName, that.lastName) && Objects.equals(mrn, that.mrn) && Objects.equals(fin, that.fin) ;
    }

    @Override
    public int hashCode() {
        return Objects.hash(childId, firstName, lastName, mrn, fin);
    }

    @OneToMany(mappedBy = "childByChildId")
    public Collection<BabyResultTableEntity> getBabyResultTablesByChildId() {
        return babyResultTablesByChildId;
    }

    public void setBabyResultTablesByChildId(Collection<BabyResultTableEntity> babyResultTablesByChildId) {
        this.babyResultTablesByChildId = babyResultTablesByChildId;
    }

    @ManyToOne
    @JoinColumn(name = "PatientID", referencedColumnName = "PatientID")
    public PatientEntity getPatientByPatientId() {
        return patientByPatientId;
    }

    public void setPatientByPatientId(PatientEntity patientByPatientId) {
        this.patientByPatientId = patientByPatientId;
    }

    @OneToMany(mappedBy = "childByChildId")
    public Collection<PatientResultEntity> getPatientResultsByChildId() {
        return patientResultsByChildId;
    }

    public void setPatientResultsByChildId(Collection<PatientResultEntity> patientResultsByChildId) {
        this.patientResultsByChildId = patientResultsByChildId;
    }
}
