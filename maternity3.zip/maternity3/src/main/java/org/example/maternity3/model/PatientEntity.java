package org.example.maternity3.model;

import javax.persistence.*;
import java.util.Collection;
import java.util.Objects;

@Entity
@Table(name = "patient", schema = "maternity", catalog = "")
public class PatientEntity {
    private int patientId;
    private String firstName;
    private String lastName;
    private String mrn;
    private String fin;
    private Collection<ChildEntity> childrenByPatientId;
    private Collection<PatientResultEntity> patientResultsByPatientId;

    @Id
    @Column(name = "PatientID", nullable = false)
    public int getPatientId() {
        return patientId;
    }

    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }

    @Basic
    @Column(name = "first_name", nullable = true, length = 40)
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @Basic
    @Column(name = "last_name", nullable = true, length = 40)
    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @Basic
    @Column(name = "MRN", nullable = false, length = 50)
    public String getMrn() {
        return mrn;
    }

    public void setMrn(String mrn) {
        this.mrn = mrn;
    }

    @Basic
    @Column(name = "FIN", nullable = false, length = 50)
    public String getFin() {
        return fin;
    }

    public void setFin(String fin) {
        this.fin = fin;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PatientEntity that = (PatientEntity) o;
        return patientId == that.patientId && Objects.equals(firstName, that.firstName) && Objects.equals(lastName, that.lastName) && Objects.equals(mrn, that.mrn) && Objects.equals(fin, that.fin);
    }

    @Override
    public int hashCode() {
        return Objects.hash(patientId, firstName, lastName, mrn, fin);
    }

    @OneToMany(mappedBy = "patientByPatientId")
    public Collection<ChildEntity> getChildrenByPatientId() {
        return childrenByPatientId;
    }

    public void setChildrenByPatientId(Collection<ChildEntity> childrenByPatientId) {
        this.childrenByPatientId = childrenByPatientId;
    }

    @OneToMany(mappedBy = "patientByPatientId")
    public Collection<PatientResultEntity> getPatientResultsByPatientId() {
        return patientResultsByPatientId;
    }

    public void setPatientResultsByPatientId(Collection<PatientResultEntity> patientResultsByPatientId) {
        this.patientResultsByPatientId = patientResultsByPatientId;
    }
}
